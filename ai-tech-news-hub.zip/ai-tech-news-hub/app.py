from pathlib import Path
import sys
from dotenv import load_dotenv
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")

from src.database import get_articles, get_filter_values, count_articles
from src.collector import collect

st.set_page_config(page_title="AI Tech News Hub", page_icon="📰", layout="wide")
st.title("📰 AI Tech News Hub")
st.caption("全球 AI 与科技新闻聚合 · 英文采集 · 中文翻译")

with st.sidebar:
    st.header("新闻控制台")
    st.metric("已收录新闻", count_articles())
    if st.button("🔄 立即采集新闻", use_container_width=True):
        with st.spinner("正在采集 RSS 新闻，请稍候…"):
            added, translated = collect()
        st.success(f"完成！新增 {added} 条，成功翻译 {translated} 条。")
        st.rerun()
    st.divider()
    search = st.text_input("搜索关键词", placeholder="例如 OpenAI、robotics、芯片")
    categories = ["All"] + get_filter_values("category")
    sources = ["All"] + get_filter_values("source")
    category = st.selectbox("新闻分类", categories)
    source = st.selectbox("新闻来源", sources)
    show_english = st.toggle("同时显示英文摘要", value=True)
    st.caption("提示：首次使用请点击“立即采集新闻”。")

articles = get_articles(search=search, category=category, source=source)
st.write(f"找到 **{len(articles)}** 条新闻")

if not articles:
    st.info("目前还没有新闻。请点击左侧“立即采集新闻”，或检查 RSS 网络连接。")
else:
    for item in articles:
        title = item.get("zh_title") or item["title"]
        with st.container(border=True):
            st.subheader(title)
            meta = " · ".join(x for x in [item.get("source"), item.get("category"), item.get("published")] if x)
            st.caption(meta)
            zh_summary = item.get("zh_summary")
            if zh_summary:
                st.write(zh_summary)
            else:
                st.write(item.get("summary") or "暂无摘要。")
            points = item.get("key_points")
            if points:
                with st.expander("核心要点"):
                    st.write(points)
            if show_english and (item.get("title") or item.get("summary")):
                with st.expander("查看英文原文摘要"):
                    st.markdown(f"**{item.get('title','')}**")
                    st.write(item.get("summary") or item.get("content") or "")
            st.markdown(f"[阅读原文 ↗]({item['url']})")
