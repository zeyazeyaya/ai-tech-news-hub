import json
import os
from pathlib import Path
from datetime import datetime, timezone
from dotenv import load_dotenv
import feedparser
import requests

from src.database import ensure_db, save_article, update_translation
from src.summarizer import translate_and_summarize
from src.utils import clean_html, normalize_url, compact_text

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

def load_feeds():
    with open(ROOT / "config" / "feeds.json", encoding="utf-8") as f:
        return json.load(f)

def collect():
    ensure_db()
    max_items = int(os.getenv("MAX_ITEMS_PER_FEED", "30"))
    timeout = int(os.getenv("REQUEST_TIMEOUT", "20"))
    session = requests.Session()
    session.headers.update({"User-Agent":"AI-Tech-News-Hub/1.0 (RSS reader)"})
    added = 0
    translated = 0

    for feed in load_feeds():
        name, category, url = feed["name"], feed.get("category","Technology"), feed["url"]
        print(f"[INFO] Fetching {name}: {url}")
        try:
            response = session.get(url, timeout=timeout)
            response.raise_for_status()
            parsed = feedparser.parse(response.content)
            if parsed.bozo and not parsed.entries:
                print(f"[WARN] Could not parse feed: {name}")
                continue
        except Exception as exc:
            print(f"[WARN] Feed failed ({name}): {exc}")
            continue

        for entry in parsed.entries[:max_items]:
            link = normalize_url(entry.get("link", ""))
            title = compact_text(clean_html(entry.get("title", "")), 500)
            if not link or not title:
                continue
            raw = entry.get("content", [{}])[0].get("value", "") if entry.get("content") else entry.get("summary", "")
            content = compact_text(clean_html(raw), 7000)
            published = entry.get("published", entry.get("updated", ""))
            article = {
                "title": title, "url": link, "source": name, "category": category,
                "published": published, "summary": compact_text(clean_html(entry.get("summary","")), 1500),
                "content": content, "zh_title": "", "zh_summary": "", "key_points": ""
            }
            if save_article(article):
                added += 1
                result = translate_and_summarize(title, article["summary"], content)
                if result:
                    update_translation(link, result)
                    translated += 1

    print(f"[DONE] New articles: {added}; translated: {translated}")
    return added, translated

if __name__ == "__main__":
    collect()
