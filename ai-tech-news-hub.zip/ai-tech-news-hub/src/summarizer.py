import json
import os
from openai import OpenAI

def translate_and_summarize(title: str, summary: str, content: str = ""):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return None
    client = OpenAI(api_key=api_key)
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    source_text = (content or summary or title)[:7000]
    prompt = f"""
请将下面这条英文 AI / 科技新闻整理成简体中文。只根据提供内容，不要补充未证实事实。
返回严格 JSON，字段：
zh_title: 中文标题
zh_summary: 约 80-150 字中文摘要
key_points: 2-4 条要点组成的字符串，每条用换行分隔
英文标题：{title}
英文内容：{source_text}
"""
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role":"system","content":"你是严谨的科技新闻编辑。忠实翻译，不夸大，不猜测。"},
                {"role":"user","content":prompt}
            ],
            response_format={"type":"json_object"},
            temperature=0.2,
        )
        data = json.loads(response.choices[0].message.content)
        return {
            "zh_title": str(data.get("zh_title","")),
            "zh_summary": str(data.get("zh_summary","")),
            "key_points": str(data.get("key_points","")),
        }
    except Exception as exc:
        print(f"[WARN] Translation failed for {title[:70]}: {exc}")
        return None
