import re
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urlunparse

def clean_html(value: str) -> str:
    if not value:
        return ""
    return BeautifulSoup(value, "html.parser").get_text(" ", strip=True)

def normalize_url(url: str) -> str:
    try:
        p = urlparse(url.strip())
        # Remove common tracking query parameters while preserving meaningful query strings.
        query = "&".join(
            part for part in p.query.split("&")
            if part and not part.lower().startswith(("utm_", "fbclid=", "gclid="))
        )
        return urlunparse((p.scheme, p.netloc.lower(), p.path.rstrip("/"), "", query, ""))
    except Exception:
        return url.strip()

def compact_text(value: str, limit: int = 1200) -> str:
    value = re.sub(r"\s+", " ", value or "").strip()
    return value[:limit]
