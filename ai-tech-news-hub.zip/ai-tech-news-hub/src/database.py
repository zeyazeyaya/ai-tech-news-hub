import os
import sqlite3
from pathlib import Path
from contextlib import contextmanager

DB_PATH = os.getenv("DATABASE_PATH", "data/news.db")

def ensure_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            url TEXT NOT NULL UNIQUE,
            source TEXT,
            category TEXT,
            published TEXT,
            summary TEXT,
            content TEXT,
            zh_title TEXT,
            zh_summary TEXT,
            key_points TEXT,
            collected_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published)")
        conn.commit()

@contextmanager
def connection():
    ensure_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def save_article(article: dict) -> bool:
    with connection() as conn:
        cur = conn.execute("""
        INSERT OR IGNORE INTO articles
        (title,url,source,category,published,summary,content,zh_title,zh_summary,key_points)
        VALUES (:title,:url,:source,:category,:published,:summary,:content,:zh_title,:zh_summary,:key_points)
        """, article)
        return cur.rowcount > 0

def update_translation(url: str, translated: dict):
    with connection() as conn:
        conn.execute("""
        UPDATE articles SET zh_title=?, zh_summary=?, key_points=? WHERE url=?
        """, (translated.get("zh_title",""), translated.get("zh_summary",""),
              translated.get("key_points",""), url))

def get_articles(search="", category="All", source="All", limit=300):
    query = "SELECT * FROM articles WHERE 1=1"
    params = []
    if search:
        query += " AND (title LIKE ? OR zh_title LIKE ? OR summary LIKE ? OR zh_summary LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term, term, term])
    if category != "All":
        query += " AND category=?"
        params.append(category)
    if source != "All":
        query += " AND source=?"
        params.append(source)
    query += " ORDER BY COALESCE(published, collected_at) DESC LIMIT ?"
    params.append(limit)
    with connection() as conn:
        return [dict(row) for row in conn.execute(query, params).fetchall()]

def get_filter_values(column):
    if column not in {"category", "source"}:
        return []
    with connection() as conn:
        rows = conn.execute(
            f"SELECT DISTINCT {column} FROM articles WHERE {column} IS NOT NULL AND {column} != '' ORDER BY {column}"
        ).fetchall()
        return [r[0] for r in rows]

def count_articles():
    with connection() as conn:
        return conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
