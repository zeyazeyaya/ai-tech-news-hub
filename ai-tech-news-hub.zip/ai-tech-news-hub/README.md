# AI Tech News Hub

一个轻量级的 AI / 人工智能 / 科技新闻聚合器：采集英文 RSS 新闻、去重、保存到 SQLite，并通过 Streamlit 网页看板阅读。配置 OpenAI API Key 后可生成中文标题、摘要和要点；未配置时仍可正常采集和阅读英文原文。

## 功能

- 聚合多个公开 RSS 来源
- 按标题 / 链接去重
- SQLite 持久化
- 网页搜索、来源筛选、分类筛选
- 可选 OpenAI 中文翻译与摘要
- 手动刷新；可通过 cron 定时采集
- 保留原文链接和发布时间

## 快速开始

建议 Python 3.10+。

```bash
git clone <你的GitHub仓库地址>
cd ai-tech-news-hub

python3 -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# 可选：编辑 .env，填写 OPENAI_API_KEY

python -m src.collector
streamlit run app.py
```

浏览器打开 Streamlit 显示的本地地址，通常是 `http://localhost:8501`。

## 配置

`.env` 示例：

```env
DATABASE_PATH=data/news.db
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o-mini
MAX_ITEMS_PER_FEED=30
REQUEST_TIMEOUT=20
```

- `OPENAI_API_KEY` 留空：只采集和展示英文内容。
- 填入有效 Key：采集后尝试生成中文标题、摘要和要点。
- 模型名称可按你账号可用的模型调整。

## 手动更新

```bash
python -m src.collector
```

也可以在网页侧边栏点击“立即采集”。

## Linux 定时采集（可选）

先确认项目绝对路径和虚拟环境路径，再编辑 crontab：

```bash
crontab -e
```

例如每 30 分钟运行一次（请替换路径）：

```cron
*/30 * * * * cd /path/to/ai-tech-news-hub && /path/to/ai-tech-news-hub/.venv/bin/python -m src.collector >> logs/collector.log 2>&1
```

## RSS 来源

默认配置见 `config/feeds.json`。RSS 地址和可用性可能变化，可自行增删。请遵守各来源的服务条款、版权要求和合理访问频率。看板默认展示标题、摘要片段和原文链接，不镜像全文。

## 项目结构

```text
ai-tech-news-hub/
├── app.py
├── config/
│   └── feeds.json
├── data/
├── logs/
├── src/
│   ├── __init__.py
│   ├── collector.py
│   ├── database.py
│   ├── summarizer.py
│   └── utils.py
├── .env.example
├── .gitignore
└── requirements.txt
```

## 常见问题

**没有抓到新闻？** 检查网络是否能访问 RSS 地址；部分网站可能临时限流或调整 feed。可先在浏览器打开 feed URL 测试。

**中文内容为空？** 确认 `.env` 中 API Key 有效，并且当前模型可用。采集流程不会因翻译失败而丢失英文新闻。

**部署到云服务器？** 建议先在本地完成首次采集，再将项目部署到 Linux；Streamlit 可先仅绑定 `127.0.0.1`，需要公网访问时再配置反向代理和访问保护，不建议直接裸露管理端口。
